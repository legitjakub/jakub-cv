<?php
/**
 * Target theme resolver for WP Puller.
 *
 * @package WP_Puller
 * @since 1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * WP_Puller_Theme_Target Class.
 */
class WP_Puller_Theme_Target {

    /**
     * Get the configured target theme stylesheet.
     *
     * Falls back to the active theme only when no target has ever been saved.
     * A saved but missing target is returned unchanged so updates fail safely
     * instead of unexpectedly modifying the active theme.
     *
     * @return string
     */
    public static function get_stylesheet() {
        $active = get_stylesheet();
        $saved  = sanitize_text_field( get_option( 'wp_puller_target_theme', $active ) );

        if ( empty( $saved ) ) {
            return $active;
        }

        return $saved;
    }

    /**
     * Get the configured target theme object.
     *
     * @param string $stylesheet Optional explicit theme stylesheet.
     * @return WP_Theme
     */
    public static function get_theme( $stylesheet = '' ) {
        if ( empty( $stylesheet ) ) {
            $stylesheet = self::get_stylesheet();
        }

        return wp_get_theme( $stylesheet );
    }

    /**
     * Check whether a theme stylesheet is installed.
     *
     * @param string $stylesheet Theme stylesheet.
     * @return bool
     */
    public static function exists( $stylesheet ) {
        $stylesheet = sanitize_text_field( $stylesheet );

        if ( empty( $stylesheet ) ) {
            return false;
        }

        $themes = wp_get_themes();

        return isset( $themes[ $stylesheet ] );
    }

    /**
     * Get all installed themes.
     *
     * @return WP_Theme[]
     */
    public static function get_available_themes() {
        $themes = wp_get_themes();

        uasort( $themes, function( $first, $second ) {
            return strcasecmp( $first->get( 'Name' ), $second->get( 'Name' ) );
        } );

        return $themes;
    }
}
